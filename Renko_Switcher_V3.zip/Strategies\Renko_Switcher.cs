#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
// AUG 21 V3 : Added Daily Profit stop and loss stop
// AUG 21 V2 : Second version updated ATR Trail switch logic 
//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class Renko_switcher : Strategy
	{
		private DM DM1;
		private SMA R2ADX5SMA;
		private ATRTrailingStop ATRTrailingStop1;
		private DM DM2;
		
		private DM DM3;
		private DM DM4;
		private ATRTrailingStop ATRTrailingStop2;
		private ATRTrailingStop ATRTrailingStop3;
		
		private int priorTradesCount = 0;
		private double priorTradesCumProfit = 0;


		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"AUG 21 12:00PM V2 Renko ATR";
				Name										= "Renko_switcher";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.IgnoreAllErrors;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				ATRLow					= 2.5;
				ATRMed				    = 3.5;
				ATRHigh					= 4.5;
				ATRMask					= 122;
				RENKO2					= 4;
				RENKO3					= 6;
				RENKO4					= 8;
				PROFIT1					= 12;
				PROFIT2					= PROFIT2+12;
				PROFIT3					= PROFIT3+12;
				PROFIT4					= PROFIT4+12;
				ADXThreshold			= 20;
				DMIThreshold			= 25;
				DAILY_PROFIT_STOP		= 1600;
				DAILY_LOSS_STOP			= 600;
			}
			else if (State == State.Configure)
			{
				AddRenko("ES 09-23",RENKO2,MarketDataType.Last);
				AddRenko("ES 09-23",RENKO3,MarketDataType.Last);
				AddRenko("ES 09-23",RENKO4,MarketDataType.Last);
			}
			else if (State == State.DataLoaded)
			{				
				DM1				= DM(Close, 14);
				DM2				= DM(Closes[1], 14);
				DM3				= DM(Closes[2], 14);
				DM4				= DM(Closes[3], 14);
				R2ADX5SMA		= SMA(DM1.ADXPlot, 5);
				
			// ATR Mask (Low[1] - Med[2] - High[3]) - Stop Switching Logic
			if (ATRMask == 111)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 112)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 113)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 121)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 122)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 123)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 131)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRHigh);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 132)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRHigh);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 133)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRLow);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRHigh);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 211)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 212)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 213)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 221)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 222)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 223)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 233)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRMed);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRHigh);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 311)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRHigh);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRLow);
			}
			
			if (ATRMask == 312)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRHigh);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRMed);
			}
			
			if (ATRMask == 313)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRHigh);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRLow);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 323)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRHigh);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRMed);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			if (ATRMask == 333)
			{
				ATRTrailingStop1				= ATRTrailingStop(Close, 5, ATRHigh);
				ATRTrailingStop2				= ATRTrailingStop(Closes[1], 5, ATRHigh);
				ATRTrailingStop3				= ATRTrailingStop(Closes[2], 5, ATRHigh);
			}
			
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 1
			|| CurrentBars[1] < 0
			|| CurrentBars[2] < 0
			|| CurrentBars[3] < 0)
				return;

			if (Bars.IsFirstBarOfSession)
			{
				// Store the strategy's prior cumulated realized profit and number of trades
				priorTradesCount = SystemPerformance.AllTrades.Count;
				//priorTradesCumProfit = SystemPerformance.RealTimeTrades.TradesPerformance.Currency.CumProfit;
				priorTradesCumProfit = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;

				/* NOTE: Using .AllTrades will include both historical virtual trades as well as real-time trades.
				If you want to only count profits from real-time trades please use .RealtimeTrades. */
			}
			

			if (SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit - priorTradesCumProfit >= DAILY_PROFIT_STOP
				|| SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit - priorTradesCumProfit <= -DAILY_LOSS_STOP)
			{
				/* TIP FOR EXPERIENCED CODERS: This only prevents trade logic in the context of the OnBarUpdate() method. If you are utilizing
				other methods like OnOrderUpdate() or OnMarketData() you will need to insert this code segment there as well. */

				// Returns out of the OnBarUpdate() method. This prevents any further evaluation of trade logic in the OnBarUpdate() method.
			//	return;
			}			
			
			
// **************** Long Setups ********************************
			 // Long entry based on base chart
			if ((CrossAbove(DM1.ADXPlot,ADXThreshold,1))
                 && (DM1.DiMinus[0] < DMIThreshold) 
				// && (DM2.DiMinus[0] < DMIThreshold) && (DM3.DiMinus[0] < DMIThreshold) 
				 && (DM1.DiPlus[0] > DM1.DiMinus[0])
				 && (DM2.DiPlus[0] > DM2.DiMinus[0]) 
				 && (DM3.DiPlus[0] > DM3.DiMinus[0]) )
			{
				EnterLong(Convert.ToInt32(DefaultQuantity), "");
				SetStopLoss("", CalculationMode.Ticks, 12, false);
			}
			
			 // Exit adx falls below 20
//			if ((CrossBelow(DM1.ADXPlot, ADXThreshold-1, 1))
//				 && (Position.MarketPosition == MarketPosition.Long))
//			{
//				ExitLong(Convert.ToInt32(DefaultQuantity), "adx_20_long_exit", "");
//			}
			
			
			 // Use Renko 2 ATR if 4 and 6 adx under 20
			if ( (Position.MarketPosition == MarketPosition.Long)
				 && (DM2.ADXPlot[0] < ADXThreshold) 
				 && (DM3.ADXPlot[0] < ADXThreshold))
			{
				SetStopLoss("", CalculationMode.Price, ATRTrailingStop1[0], false);
			}

			 // Switch to Renko4 if ADX 4 is above 20 and ADX 6 is below 20 - only if ATRTstop2 is higher than entry price, else stay on 'prior switch'
			if ( (Position.MarketPosition == MarketPosition.Long)
				 && (DM2.ADXPlot[0] > ADXThreshold) 
				 && (DM3.ADXPlot[0] < ADXThreshold))
			{
				if (ATRTrailingStop2[0] > Position.AveragePrice)
				{
					SetStopLoss("", CalculationMode.Price, ATRTrailingStop2[0], false);
				}
			}
			
			// Switch to Renko6 if ADX 6 is above 20 - only if ATRTstop3 is higher than entry price, else stay on 'prior switch'
			if ( (Position.MarketPosition == MarketPosition.Long)
				&& (DM3.ADXPlot[0] > ADXThreshold) )
			{
				if (ATRTrailingStop3[0] > Position.AveragePrice)
				{
					SetStopLoss("", CalculationMode.Price, ATRTrailingStop3[0], false);
				}	
			}
	 			

// **************** Short Setups ********************************
			 // Short entry based on base chart
			if ((CrossAbove(DM1.ADXPlot,ADXThreshold,1))
                 && (DM1.DiPlus[0] < DMIThreshold) 
				 && (DM1.DiPlus[0] < DM1.DiMinus[0])
				 && (DM2.DiPlus[0] < DM2.DiMinus[0]) 
				 && (DM3.DiPlus[0] < DM3.DiMinus[0]) )
			{
				EnterShort(Convert.ToInt32(DefaultQuantity), "");
				SetStopLoss("", CalculationMode.Ticks, 12, false);
			}
			
			 // Exit adx falls below 20
//			if ((CrossBelow(DM1.ADXPlot, ADXThreshold-1, 1))
//				 && (Position.MarketPosition == MarketPosition.Short))
//			{
//				ExitShort(Convert.ToInt32(DefaultQuantity), "adx_20_short_exit", "");
//			}
			
			
			 // Use Renko 2 ATR if ADX 4 and 6 under 20
			if ( (Position.MarketPosition == MarketPosition.Short)
				 && (DM2.ADXPlot[0] < ADXThreshold) 
				 && (DM3.ADXPlot[0] < ADXThreshold))
			{
				SetStopLoss("", CalculationMode.Price, ATRTrailingStop1[0], false);
			}

			 // Switch to Renko4 if ADX 4 is above 20 and ADX 6 is below 20 - only if ATRTstop2 is lower than entry price, else stay with 'prior switch'
			if ( (Position.MarketPosition == MarketPosition.Short)
				 && (DM2.ADXPlot[0] > ADXThreshold) 
				 && (DM3.ADXPlot[0] < ADXThreshold))
			{
				if (ATRTrailingStop2[0] < Position.AveragePrice)
				{
					SetStopLoss("", CalculationMode.Price, ATRTrailingStop2[0], false);
				}
			}
			
			// Switch to Renko6 if ADX 6 is above 20 - only if ATRTstop3 is lower than entry price, else stay with 'prior switch'
			if ( (Position.MarketPosition == MarketPosition.Short)
				 && (DM3.ADXPlot[0] > ADXThreshold) )
			{
				if (ATRTrailingStop3[0] < Position.AveragePrice)
				{
					SetStopLoss("", CalculationMode.Price, ATRTrailingStop3[0], false);
				}
			}
			
			 
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="ATRLow", Description="ATR Low ", Order=1, GroupName="Parameters")]
		public double ATRLow
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="ATRMed", Description="ATR Med", Order=2, GroupName="Parameters")]
		public double ATRMed
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="ATRHigh", Description="ATR High", Order=3, GroupName="Parameters")]
		public double ATRHigh
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Range(1, double.MaxValue)]
		[Display(Name="ATR Mask", Description="ATR Mask (111 to 333)", Order=4, GroupName="Parameters")]
		public double ATRMask
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="RENKO2", Description="Second Chart Brick Size ", Order=5, GroupName="Parameters")]
		public int RENKO2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="RENKO3", Description="Third Chart Brick Size ", Order=6, GroupName="Parameters")]
		public int RENKO3
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="RENKO4", Description="Forth Chart Brick Size ", Order=7, GroupName="Parameters")]
		public int RENKO4
		{ get; set; }
	
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PROFIT_TARGET_1", Description="First Chart Profit Target ", Order=8, GroupName="Parameters")]
		public int PROFIT1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PROFIT_TARGET_2", Description="Second Chart Profit Target ", Order=9, GroupName="Parameters")]
		public int PROFIT2
		{ get; set; }
	
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PROFIT_TARGET_3", Description="Third Chart Profit Target ", Order=10, GroupName="Parameters")]
		public int PROFIT3
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PROFIT_TARGET_4", Description="Fourth Chart Profit Target ", Order=11, GroupName="Parameters")]
		public int PROFIT4
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ADXThreshold", Description="ADX Threshold ", Order=12, GroupName="Parameters")]
		public int ADXThreshold
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DMIThreshold", Description="DMI/Paaji Threshold ", Order=13, GroupName="Parameters")]
		public int DMIThreshold
		{ get; set; }
	
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DAILY_PROFIT_STOP", Description="Daily Profit Target ", Order=14, GroupName="Parameters")]
		public int DAILY_PROFIT_STOP
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="DAILY_LOSS_STOP", Description="Daily Loss STOP ", Order=15, GroupName="Parameters")]
		public int DAILY_LOSS_STOP
		{ get; set; }
		
		#endregion

	}
}
